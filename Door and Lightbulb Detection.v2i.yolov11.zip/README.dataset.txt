# Door and Lightbulb Detection > 2025-12-14 4:26pm
https://universe.roboflow.com/it3103-oxven/door-and-lightbulb-detection-g7vaw

Provided by a Roboflow user
License: CC BY 4.0

